//
//  ViewController.swift
//  Level_Supermind
//
//  Created by Snehal Patil on 01/02/25.
//

import UIKit



class ViewController: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
    }


}

