//
//  Insights_View.swift
//  Level_Supermind
//
//  Created by Snehal Patil on 02/02/25.
//

import UIKit

class Insights_View: UIViewController {

    @IBOutlet weak var myStatistic_CV: UICollectionView!
    
    var poster_Img = ["Frame 1171277217" , "Frame 1171277216" , "Frame 1171277215"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true


    }
    


}

extension Insights_View : UICollectionViewDataSource , UICollectionViewDelegate , UICollectionViewDelegateFlowLayout {
   
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return poster_Img.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
      
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Mystatistic_CVC", for: indexPath) as! Mystatistic_CVC
        
        cell.poster_Img.image = UIImage(named: poster_Img[indexPath.row])
        cell.layer.cornerRadius = 10
        
        return cell
        
        
    }
    
    
func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
    
    return CGSize(width: (collectionView.bounds.width - 20) / 3.0 , height: 200 )
    
}
    
    
    
}
