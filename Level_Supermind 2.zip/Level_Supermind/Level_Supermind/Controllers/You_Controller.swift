//
//  You_Controller.swift
//  Level_Supermind
//
//  Created by Snehal Patil on 02/02/25.
//

import UIKit

class You_Controller: UIViewController {

 
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var mainStackView: UIStackView!
    @IBOutlet weak var myLibraryStackView: UIStackView!
    @IBOutlet weak var insightStackView: UIStackView!
    @IBOutlet weak var ViewHeight: NSLayoutConstraint!
    @IBOutlet weak var setting_Btn: UIButton!
    
    @IBOutlet weak var myLibrary_Text: UILabel!
    @IBOutlet weak var myLibrary_View: UIView!
    @IBOutlet weak var Insights_Text: UILabel!
    @IBOutlet weak var Insights_View: UIView!
    
    
    
    var firstV : UIViewController!
    var secinfV :MyLibrary_View!
    var thirdV : Insights_View!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("dncancankcjkac")
        myLibraryStackView.layer.masksToBounds = true
        insightStackView.layer.masksToBounds = true
       self.navigationController?.isNavigationBarHidden = true
        setting_Btn.setTitle("", for: .normal)
        drawerViewAndOther()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(animated)
           self.mainView.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
       }
       
       override func viewWillDisappear(_ animated: Bool) {
           super.viewWillDisappear(animated)
           self.mainView.removeObserver(self, forKeyPath: "contentSize")
       }
       
       override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
           if keyPath == "contentSize" {
               if let newValue = change?[.newKey] as? CGSize {
                   ViewHeight.constant = newValue.height
               }
           }
       }
    
    override func viewWillLayoutSubviews() {
        drawerViewAndOther()
        if firstV == nil{
            
            firstV = self.storyboard?.instantiateViewController(withIdentifier: "MyLibrary_View")as! MyLibrary_View
            self.addChild(firstV)
            self.firstV.view.frame.size.height = self.mainView.frame.size.height
            self.firstV.view.frame.size.width = self.mainView.frame.size.width
            self.mainView.addSubview((firstV?.view)!)
            self.mainView.addSubview((firstV?.view)!)
        
            
            
            
        } else if thirdV == nil {
            
            thirdV = (self.storyboard?.instantiateViewController(withIdentifier: "Insights_View")as! Insights_View)
            self.addChild(firstV)
            
            self.thirdV.view.frame.size.height = self.mainView.frame.size.height
            self.thirdV.view.frame.size.width = self.mainView.frame.size.width
            self.mainView.addSubview((thirdV?.view)!)
          
            
        }
    
    }
    
    
    @objc func myLibraryTapped(sender : UITapGestureRecognizer){
        print("NNNNNNNNNNNNNNNNNNNNN")
        if firstV == nil{
            firstV = self.storyboard?.instantiateViewController(withIdentifier: "MyLibrary_View")as! MyLibrary_View
            
      }
        self.addChild(firstV)
        
        self.firstV.view.frame.size.height = self.mainView.frame.size.height
        self.firstV.view.frame.size.width = self.mainView.frame.size.width
        self.mainView.addSubview((firstV?.view)!)
        
        myLibrary_Text.textColor = UIColor(named: "White")
        myLibrary_View.backgroundColor = UIColor(named: "White")
        
        Insights_Text.textColor = UIColor(named: "Shed")
        Insights_View.backgroundColor = UIColor(named: "Shed")

        
    }
    
    @objc func insightTapped(sender : UITapGestureRecognizer){

        if thirdV == nil{
            thirdV = (self.storyboard?.instantiateViewController(withIdentifier: "Insights_View")as! Insights_View)
        }
        
        self.addChild(thirdV)
        
        self.thirdV.view.frame.size.height = mainView.frame.size.height
       
        self.mainView.addSubview((thirdV?.view)!)
        
        myLibrary_Text.textColor = UIColor(named: "Shed")
        myLibrary_View.backgroundColor = UIColor(named: "Shed")
        
        Insights_Text.textColor = UIColor(named: "White")
        Insights_View.backgroundColor = UIColor(named: "White")
        
    }
    
    
    func drawerViewAndOther(){
    
        let myLibraryPage = UITapGestureRecognizer(target: self, action: #selector(myLibraryTapped(sender:)))
        self.myLibraryStackView.addGestureRecognizer(myLibraryPage)
        
        let InsightsPage = UITapGestureRecognizer(target: self, action: #selector(insightTapped(sender:)))
        self.insightStackView.addGestureRecognizer(InsightsPage)
        
    }
    

}
