//
//  Today_ViewController.swift
//  Level_Supermind
//
//  Created by Snehal Patil on 02/02/25.
//

import UIKit

struct LevelSuperMindContent {
    var titleNames: [String]
    var imageSet: [String]
    var genres: [String]
    var iconSet: [String]
    var featuredImages: [String]
}

let meditationData = LevelSuperMindContent(
    titleNames: ["Explore", "Recommended For You", "Recents", "Learn", "Featured"],
    imageSet: ["Card top half (2)", "Card top half (1)", "meditation-yoga-background_68067-412"],
    genres: ["Meditation - 5 Min", "Meditation - 6 Min", "Meditation - 8 Min"],
    iconSet: ["Mind", "Body", "Sleep", "More", "Frame 427322764", "Frame 427322766",
              "Frame 427322764 (1)", "Frame 427322767", "Frame 427322765",
              "Frame 427322767 (1)", "Frame 427322766 (1)", "Frame 427322765 (1)"],
    featuredImages: ["meditation-yoga-background_68067-412", "images"]
)



class Today_ViewController: UIViewController {

    @IBOutlet weak var Today_TV: UITableView!
    @IBOutlet weak var todayView: UIView!
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(animated)
           self.Today_TV.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
       }
       
       override func viewWillDisappear(_ animated: Bool) {
           super.viewWillDisappear(animated)
           self.Today_TV.removeObserver(self, forKeyPath: "contentSize")
       }
       
       override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
           if keyPath == "contentSize" {
               if let newValue = change?[.newKey] as? CGSize {
                   tableViewHeight.constant = newValue.height
               }
           }
       }
    
   

}

extension Today_ViewController : UITableViewDelegate , UITableViewDataSource {
  
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return meditationData.titleNames.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Todays_TVC", for: indexPath) as! Todays_TVC
            cell.title_Lbl.text = meditationData.titleNames[indexPath.row]
            switch indexPath.row {
            case 0 : cell.seeAll_Btn.isHidden = true
                case 1 :cell.seeAll_Btn.isHidden = true
                case 2 :cell.seeAll_Btn.isHidden = false
                case 3: cell.seeAll_Btn.isHidden = true
                case 4: cell.seeAll_Btn.isHidden = true
                default: cell.seeAll_Btn.isHidden = true
            }
            
            cell.sectionIndex = indexPath.row
            cell.todays_CV.reloadData()
            
            return cell
        }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            switch indexPath.row {
                case 0: return 300
                case 1, 2: return 260
                case 3: return 200
                case 4: return 300
                default: return 300
               
            }
        }
    
    
    
}
