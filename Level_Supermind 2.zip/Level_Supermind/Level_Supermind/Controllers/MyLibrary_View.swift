//
//  MyLibrary_View.swift
//  Level_Supermind
//
//  Created by Snehal Patil on 02/02/25.
//

import UIKit
import SDWebImage

class MyLibrary_View: UIViewController {
    
    
    
    @IBOutlet weak var recentLibrary_CV: UICollectionView!
    @IBOutlet weak var seeAll_Btn: UIButton!
    
    
    var imageSet = ["Card top half (2)" , "Card top half (1)" ,"meditation-yoga-background_68067-412"]
    
    var gener = ["Meditation - 5 Min" , "Meditation - 6 Min" , "Meditation - 8 Min"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
 
        self.navigationController?.isNavigationBarHidden = true
        
    }
    
}
    
extension MyLibrary_View : UICollectionViewDataSource , UICollectionViewDelegate ,UICollectionViewDelegateFlowLayout {
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return imageSet.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "recentPlayed_CVC", for: indexPath) as! recentPlayed_CVC
        
        cell.Recent_Img.image = UIImage(named: imageSet[indexPath.row])
        cell.layer.cornerRadius = 10
        
        return cell
    }
    
        
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: (collectionView.bounds.width - 20) / 3.0 , height: 200 )
        
    }
        
        
    }
