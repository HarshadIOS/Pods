//
//  Recomended_CVC.swift
//  Level_Supermind
//
//  Created by Snehal Patil on 02/02/25.
//

import UIKit

class Recomended_CVC: UICollectionViewCell {
    
    @IBOutlet weak var recomended_Img: UIImageView!
    
    
    
}
