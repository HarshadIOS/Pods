//
//  recentPlayed_CVC.swift
//  Level_Supermind
//
//  Created by Snehal Patil on 02/02/25.
//

import UIKit

class recentPlayed_CVC: UICollectionViewCell {
    
    @IBOutlet weak var Recent_Img: UIImageView!
    @IBOutlet weak var gener_Lbl: UILabel!
    @IBOutlet weak var title_Lbl: UILabel!
    @IBOutlet weak var creator_Lbl: UILabel!
    
    
}
