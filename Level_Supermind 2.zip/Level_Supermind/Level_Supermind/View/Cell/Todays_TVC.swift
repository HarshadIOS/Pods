//
//  Todays_TVC.swift
//  Level_Supermind
//
//  Created by Snehal Patil on 02/02/25.
//

import UIKit
import SDWebImage

class Todays_TVC: UITableViewCell {

    @IBOutlet weak var title_Lbl: UILabel!
    
    @IBOutlet weak var seeAll_Btn: UILabel!
    
    @IBOutlet weak var todays_CV: UICollectionView!
 
    var sectionIndex: Int = 0

 
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
        todays_CV.dataSource = self
        todays_CV.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = (sectionIndex == 0) ? .vertical : .horizontal
        todays_CV.collectionViewLayout = layout
        todays_CV.reloadData()
    }

}

extension Todays_TVC : UICollectionViewDataSource , UICollectionViewDelegate , UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
           switch sectionIndex {
               case 0: return meditationData.iconSet.count
               case 1, 2: return meditationData.imageSet.count
               case 3: return meditationData.genres.count
               case 4: return meditationData.featuredImages.count
               default: return 0
           }
       }

       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           switch sectionIndex {
               case 0:
                   let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Explore_CVC", for: indexPath) as! Explore_CVC
                   cell.explore_Icon.image = UIImage(named: meditationData.iconSet[indexPath.row])
               cell.layer.cornerRadius = 10
                   return cell
               
               case 1, 2:
                   let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Recomended_CVC", for: indexPath) as! Recomended_CVC
                   cell.recomended_Img.image = UIImage(named: meditationData.imageSet[indexPath.row])
               cell.layer.cornerRadius = 10
                   return cell
               
               case 3:
                   let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Learn_CVC", for: indexPath) as! Learn_CVC
                   cell.learn_Img.image = UIImage(named: meditationData.imageSet[indexPath.row])
               cell.layer.cornerRadius = 10
                   return cell
               
               case 4:
                   let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Featured_CVC", for: indexPath) as! Featured_CVC
                cell.featured_Img.image = UIImage(named: meditationData.featuredImages[indexPath.row])
               cell.layer.cornerRadius = 10
               return cell
               
               default:
                   return UICollectionViewCell()
           }
       }
       
       func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       
           let width = collectionView.frame.width
           let height = collectionView.frame.height
           
           switch sectionIndex {
               case 0:
                   return CGSize(width: (width / 3) - 24, height: height / 2)
             
           case 1 , 2:
                   return CGSize(width: (width / 3 ) - 16, height: height)
               
               
           case 3:
              
               return CGSize(width: width - 10, height: height - 32)
               
           case 4:
              
               return CGSize(width: width - 16, height: height)
               
               default:
                   return CGSize(width: 0, height: 0)
           }
       }
    
    
    }

    


