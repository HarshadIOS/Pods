//
//  Explore_CVC.swift
//  Level_Supermind
//
//  Created by Snehal Patil on 02/02/25.
//

import UIKit

class Explore_CVC: UICollectionViewCell {
   
    @IBOutlet weak var explore_Icon: UIImageView!
    
    
    
}
