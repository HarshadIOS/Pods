//
//  Featured_CVC.swift
//  Level_Supermind
//
//  Created by Snehal Patil on 02/02/25.
//

import UIKit

class Featured_CVC: UICollectionViewCell {
    
    @IBOutlet weak var featured_Img: UIImageView!
    
    @IBOutlet weak var description_Lbl : UILabel!
    
}
