//
//  Learn_CVC.swift
//  Level_Supermind
//
//  Created by Snehal Patil on 02/02/25.
//

import UIKit

class Learn_CVC: UICollectionViewCell {
  
    @IBOutlet weak var learn_Img: UIImageView!
    
    
}
